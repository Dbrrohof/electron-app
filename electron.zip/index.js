const Config = require('electron-config');
const config = new Config()

var cfg = config.get('user')

document.getElementById('welcome-text').innerHTML = "Welcome, " + cfg.name +"!";
